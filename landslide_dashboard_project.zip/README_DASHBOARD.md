# Landslide Detection Streamlit Dashboard

This is a production-ready Streamlit prototype for RGB + NDVI landslide segmentation dashboarding.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy to Streamlit Community Cloud

1. Add `app.py` and `requirements.txt` to your GitHub repository root.
2. Go to Streamlit Community Cloud.
3. Click **New app**.
4. Select your repository and branch.
5. Set main file path to `app.py`.
6. Deploy.

## Model integration

The current `predict_landslide()` function uses a realistic image-processing placeholder. Replace it with your trained U-Net or FCN inference code.

Suggested folder structure:

```text
-Landslide-Detection-UNet-FCN/
├── app.py
├── requirements.txt
├── models/
│   ├── unet_model.pth or unet_model.h5
│   └── fcn_model.pth or fcn_model.h5
├── sample_data/
│   ├── rgb_sample.png
│   └── nir_sample.png
└── outputs/
```
